import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:bloom_health_app/features/bloom/domain/entities/glucose_entity.dart';
import 'package:bloom_health_app/features/bloom/domain/usecases/glucose_usecases/get_glucose_entries.dart';

import '../../domain/usecases/glucose_usecases/add_glucose_entry_usecase.dart';

class GlucoseViewModel extends StateNotifier<AsyncValue<List<GlucoseEntity>>> {
  final GetGlucoseEntries getGlucoseEntries;
  final AddGlucoseEntry addGlucoseEntry;

  GlucoseViewModel(this.getGlucoseEntries,this.addGlucoseEntry,
      ) : super(const AsyncValue.loading()) {
    loadGlucose();
  }

  Future<void> loadGlucose({DateTime? from, DateTime? to}) async {
    state = const AsyncValue.loading();
    try {
      final entries = await getGlucoseEntries(from: from, to: to);
      state = AsyncValue.data(entries);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
  Future<void> addEntry(GlucoseEntity entry) async {
    try {
      await addGlucoseEntry(entry);
      await loadGlucose(); // refresh after adding
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}
