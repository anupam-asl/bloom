import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:bloom_health_app/features/bloom/domain/entities/glucose_entity.dart';
import 'package:bloom_health_app/features/bloom/presentation/viewmodels/glucose_providers.dart';
import 'package:bloom_health_app/features/bloom/presentation/widgets/homepage_widgets/homepage_header.dart';
import 'package:bloom_health_app/features/bloom/presentation/widgets/homepage_widgets/bottom_navbar.dart';
import 'package:bloom_health_app/features/bloom/presentation/widgets/homepage_widgets/homepage_petalchart.dart';
import 'package:bloom_health_app/features/bloom/presentation/widgets/homepage_widgets/homepage_reminder_card.dart';
import 'package:fpdart/fpdart.dart';
import '../widgets/homepage_widgets/homepage_greetings.dart';

class BloomHomePage extends ConsumerStatefulWidget {
  const BloomHomePage({super.key});

  @override
  ConsumerState<BloomHomePage> createState() => _BloomHomePageState();
}

class _BloomHomePageState extends ConsumerState<BloomHomePage> {
  bool _showReminder = false;
  Timer? _dummyDataTimer;

  @override
  void initState() {
    super.initState();

    debugPrint(" BloomHomePage initState — setting up dummy glucose data");

    // Add one glucose reading immediately after build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _insertRandomGlucose();
    });

    // Add glucose reading every 1 minute
    _dummyDataTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      debugPrint(" 1 minute passed — inserting new glucose value");

      _insertRandomGlucose();
    });
  }

  void _insertRandomGlucose() {
    final random = Random();
    final value = 10 + random.nextInt(91); // 10–100

    final entity = GlucoseEntity(
      dateTime: DateTime.now(),
      valueMgDl: value,
    );

    ref.read(glucoseViewModelProvider.notifier).addGlucoseEntry(entity);



    debugPrint("Inserted dummy glucose: $value mg/dL");
  }

  @override
  void dispose() {
    debugPrint(" BloomHomePage dispose — cancelling dummy data timer");

    _dummyDataTimer?.cancel();
    super.dispose();
  }

  void _handleAnimationComplete() {
    setState(() {
      _showReminder = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isLandscape = constraints.maxWidth > constraints.maxHeight;
            final double chartSize = (constraints.maxWidth < constraints.maxHeight
                ? constraints.maxWidth
                : constraints.maxHeight) * 0.85;

            Widget mainColumn = Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(height: constraints.maxHeight * 0.04),
                const HomePageHeader(),
                SizedBox(height: constraints.maxHeight * 0.02),
                const FlourishGreeting(),
                SizedBox(height: constraints.maxHeight * 0.04),
                Center(
                  child: SizedBox(
                    width: chartSize,
                    height: chartSize,
                    child: HomepagePetalChart(
                      onAnimationComplete: _handleAnimationComplete,
                    ),
                  ),
                ),
                const Spacer(),
                if (_showReminder)
                  ReminderCard(
                    message: 'Post-breakfast activity aids digestion - take the stairs to boost your bloom at work.',
                    onTap: () {},
                  ),
                if (_showReminder) const SizedBox(height: 28),
              ],
            );

            return isLandscape
                ? SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: constraints.maxWidth * 0.06),
              child: mainColumn,
            )
                : Padding(
              padding: EdgeInsets.symmetric(horizontal: constraints.maxWidth * 0.06),
              child: mainColumn,
            );
          },
        ),
      ),
      bottomNavigationBar: const BottomNavbar(),
    );
  }
}
