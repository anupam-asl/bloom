import 'package:flutter/material.dart';
import 'package:bloom_health_app/features/bloom/presentation/viewmodels/bloom_dashboard_vm.dart';
import 'dart:math';

import 'HealthScoreCircle.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:bloom_health_app/features/bloom/presentation/viewmodels/glucose_providers.dart';

class HomepagePetalChart extends ConsumerStatefulWidget {

  final VoidCallback? onAnimationComplete;

  const HomepagePetalChart({
    super.key,
    this.onAnimationComplete,
  });

  @override
  ConsumerState<HomepagePetalChart> createState() => _HomepagePetalChartState();
}

class _HomepagePetalChartState extends ConsumerState<HomepagePetalChart>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _rotationAnim;
  late final Animation<double> _fillAnim;

  double _lastGlucosePerc = 0.0;
  double _currentGlucosePerc = 0.0;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _rotationAnim = Tween<double>(
      begin: pi / 8,
      end: 0.0,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.7, curve: Curves.easeOutCubic),
      ),
    );

    _fillAnim = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.7, 1.0, curve: Curves.easeOutCubic),
      ),
    );
    //  Call the callback when the animation finishes
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed &&
          widget.onAnimationComplete != null) {
        widget.onAnimationComplete!();
      }
    });

    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    final glucoseAsync = ref.watch(glucoseStreamProvider);

    double glucoseValue = 0;

    glucoseAsync.when(
      data: (entries) {
        if (entries.isNotEmpty) {
          glucoseValue = entries.last.valueMgDl.toDouble();
        }
      },
      loading: () => glucoseValue = 0,
      error: (e, st) => glucoseValue = 0,
    );

    const double minGlucose = 10;
    const double maxGlucose = 100;
    double newGlucosePerc = ((glucoseValue - minGlucose) / (maxGlucose - minGlucose))
        .clamp(0.0, 1.0);

    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final size = MediaQuery.of(context).size;
        final minSide = size.shortestSide * 0.85;
        final halfSide = minSide / 2;

        return Transform.rotate(
          angle: _rotationAnim.value,
          child: SizedBox(
            width: minSide,
            height: minSide,
            child: Stack(
              children: [
                Center(
                  child: SvgPicture.asset(
                    'assets/images/petals/score_petals_bg.svg',
                    width: minSide,
                  ),
                ),

                // Other petals stay as before...
                _fillAnim.value > 0
                    ? getCaloriePositioned(halfSide, 0.0 * _fillAnim.value)
                    : const SizedBox(),
                _fillAnim.value > 0
                    ? getActivitiesPositioned(halfSide, 0.25 * _fillAnim.value)
                    : const SizedBox(),

                // Glucose petal animates ONLY when value changes
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(
                    begin: _lastGlucosePerc,
                    end: newGlucosePerc,
                  ),
                  duration: const Duration(milliseconds: 800),
                  onEnd: () => _lastGlucosePerc = newGlucosePerc,
                  builder: (context, value, _) {
                    return getGlucosePositioned(halfSide, value);
                  },
                ),

                _fillAnim.value > 0
                    ? getSleepPositioned(halfSide, 0.50 * _fillAnim.value)
                    : const SizedBox(),

                Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: halfSide / 2.7,
                    height: halfSide / 2.7,
                    child: HealthScoreCircle(
                      score: _rotationAnim.isCompleted
                          ? (5 * _fillAnim.value).round()
                          : null,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}


  Positioned getCaloriePositioned(double halfSide, double percValue) {

    final displayPerc = percValue * 0.7;

    final normalizedScale = displayPerc.clamp(0.0, 0.7);
    final H = halfSide;

    double leftOffset = 0;
    double topOffset = 0;

    if (displayPerc < 0.7) {
      leftOffset = -18.3333 * (displayPerc - 0.7);
      topOffset = 23.3333 * (displayPerc - 0.7);
    }

    return Positioned(
      left: halfSide + leftOffset,
      top: topOffset,
      width: halfSide,
      height: halfSide,
      child: Align(
        alignment: Alignment.bottomLeft,
        child: SizedBox(
          width: halfSide * normalizedScale,
          height: halfSide * normalizedScale,
          child: SvgPicture.asset(
            'assets/images/petals/calories_orange_fg.svg',
            fit: BoxFit.contain,
          ),
        ),
      ),
    );
  }


  Positioned getActivitiesPositioned(double halfSide, double percValue) {
    final displayPerc = percValue * 0.7;

    final normalizedScale = displayPerc.clamp(0.0, 0.7);
    final H = halfSide;

    double leftOffset = 0;
    double topOffset = 0;

    if (displayPerc < 0.7) {
      leftOffset = -18.3333 * (displayPerc - 0.7);
      topOffset = 23.3333 * (displayPerc - 0.7);
    }

    return Positioned(
      left: halfSide+leftOffset,
      top: halfSide-topOffset,
      width: halfSide,
      height: halfSide,
      child: Container(
        // color: Colors.purple.withOpacity(0.2),
        child: Align(
          alignment: Alignment.topLeft,
          child: SizedBox(
            width: halfSide * normalizedScale,
            height: halfSide * normalizedScale,
            child: SvgPicture.asset(
              'assets/images/petals/activities_pink_fg.svg',
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }

  Positioned getGlucosePositioned(double halfSide, double percValue) {
    final displayPerc = percValue * 0.7;

    final normalizedScale = displayPerc.clamp(0.0, 0.7);
    final H = halfSide;

    double leftOffset = 0;
    double topOffset = 0;

    if (displayPerc < 0.7) {
      leftOffset = -18.3333 * (displayPerc - 0.7);
      topOffset = 23.3333 * (displayPerc - 0.7);
    }

    return Positioned(
      left: 0-leftOffset,
      top: 0+topOffset,
      width: halfSide,
      height: halfSide,
      child: Container(
        // color: Colors.purple.withOpacity(0.2),
        child: Align(
          alignment: Alignment.bottomRight,
          child: SizedBox(
            width: halfSide * normalizedScale,
            height: halfSide * normalizedScale,
            child: SvgPicture.asset(
              'assets/images/petals/glucose_purple_fg.svg',
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }

  Positioned getSleepPositioned(double halfSide, double percValue) {
    final displayPerc = percValue * 0.7;

    final normalizedScale = displayPerc.clamp(0.0, 0.7);
    final H = halfSide;

    double leftOffset = 0;
    double topOffset = 0;

    if (displayPerc < 0.7) {
      leftOffset = -18.3333 * (displayPerc - 0.7);
      topOffset = 23.3333 * (displayPerc - 0.7);
    }
    return Positioned(
      left: 0-leftOffset,
      top: halfSide-topOffset,
      width: halfSide,
      height: halfSide,
      child: Container(
        // color: Colors.purple.withOpacity(0.2),
        child: Align(
          alignment: Alignment.topRight,
          child: SizedBox(
            width: halfSide * normalizedScale,
            height: halfSide * normalizedScale,
            child: SvgPicture.asset(
              'assets/images/petals/sleep_blue_fg.svg',
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }


