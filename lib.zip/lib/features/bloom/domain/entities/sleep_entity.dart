class SleepEntity {
  final String? dateTime;
  final String sleepState; // e.g., "asleep", "awake"
  final int? heartRate;
  final int? respiratoryRate;
  final SleepStages? stages;

  SleepEntity({
    // required this.dateTime,
    this.dateTime,
    required this.sleepState,
    this.heartRate,
    this.respiratoryRate,
    this.stages,
  });
}

class SleepStages {
  final Duration light;
  final Duration deep;
  final Duration rem;

  SleepStages({
    required this.light,
    required this.deep,
    required this.rem,
  });
}
